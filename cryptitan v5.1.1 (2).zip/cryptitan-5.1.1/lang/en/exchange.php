<?php

return [
    'buy_description' => 'Bought :coin with :currency',
    'sell_description' => 'Sold :coin for :currency',
    'swap_description' => 'Swap :sell with :buy',
];
