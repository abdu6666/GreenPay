<?php

return [
    'required' => 'License is required.',
    'unavailable' => 'License server is unavailable.',
    'invalid' => 'Invalid license.',
];
