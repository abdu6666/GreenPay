<?php

return [
    'enabled' => 'Two factor enabled.',
    'invalid_token' => 'The two factor token is invalid.',
];
